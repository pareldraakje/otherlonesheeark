This is the Other Lone Shee Ark, also known as the OLS.


To install, place the .agents file in the /agents folder of your DS installation.

This doesn't work in C3 standalone.



Credits:
Background, items & coding: Pilla
Some of the background images are taken from C2, some from Google with a million filters slapped on.

You are free to reuse any coding however you want.
You're free to re-release any of the plants/animals in a 'pack' of some kind, or as a sub-thing of an agent. (eg a vendor)

Some credit in the help text would be nice.

If the download I hosted at http://goo.gl/xPTxQX doesn't work anymore, you're free to rehost.

You can contact me on pilla@live.be anytime.

If I disappear from earth and there's no way to contact me anymore, you're free to update/improve on the code or the images and re-release.

Enjoy!